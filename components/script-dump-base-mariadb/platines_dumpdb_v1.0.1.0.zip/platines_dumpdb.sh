#!/bin/bash
################################################################################
#
# $Header: platines_dumpdb.sh 11-nov-2017 10:26:00 
#
# Script       : platines_dumpdb.sh 
# Auteur       : Jean-Marc Belorgane (Henix)
# Creation     : 10-11-2017 10:26:00
# Version      : 1.0.0.0
# Description  : Script de generation du dump de la BDD MARIADB Platines.
#                --
#                En sortie :
#                Format du fichier dump : mysqldump_platines_AAAAMMJJ_HHMNSS.sql.zip
#                Format du fichier logs : platines_dumpdb_AAAAMMJJ_HHMNSS.log
#
################################################################################
#
# Modification : 13-03-2018, 14:30:00, JM Belorgane, Vers. 1.0.1.0
#                Ajout de l'argument facultatif [-m] pour affecter le nom du 
#                service MariaDB.
# ------------------------------------------------------------------------------
# Modification : JJ-MM-AAAA, HH:MN:SS, Auteur, Vers. N.N.N.N
#                Description evolution
# ------------------------------------------------------------------------------
#
################################################################################


#===============================================================================
#> Trace_log() : Trace une ligne de texte dans le fichier de logs
#===============================================================================
# arg. 1 : Libelle du texte a tracer
#===============================================================================
Trace_log(){
    # Declaration des variables locales
    local _LIB_TXT="$*"

    # Trace la ligne de texte dans le fichier de logs si il existe
    [ "${LOG_FILE}x" != "x" -a -f "${LOG_FILE}" ] && echo -e "[$(date "+%d-%m-%Y %H:%M:%S")] : ${_LIB_TXT}" >> ${LOG_FILE}

    # Code retour de la fonction
    return 0
}


#===============================================================================
#> Sortie() : Traitement de sortie du script
#===============================================================================
#  arg. 1 : Code de sortie du script
#  arg. 2 : Libelle de sortie ou d'erreur
#===============================================================================
Sortie(){
    # Suppression des fichiers de travail
    [ ! -z "${TMP_FILE}" ] && rm -f ${TMP_FILE}

    # Affichage du libelle de sortie ou d'erreur si necessaire
    if [ "x$2" != "x" ]
    then 
        echo -e "$2"
        [ "${LOG_FILE}x" != "x" -a -f "${LOG_FILE}" ] && echo -e "\n[$(date "+%d-%m-%Y %H:%M:%S")] : $2" >> ${LOG_FILE}
    fi
    if [ $1 -eq 0 ]
    then 
        Trace_log "(${SCRIPT_NAME}) v${SCRIPT_VERSION} : Fin normale du traitement "
    else
        Trace_log "(${SCRIPT_NAME}) v${SCRIPT_VERSION} : Sortie en erreur ($1) "
    fi

    [ "${LOG_FILE}x" != "x" -a -s "${LOG_FILE}" ] && echo -e "Fichier logs genere  : ${LOG_FILE} "

    # Sortie du script avec le code retour approprie
    exit $1
}


#===============================================================================
#> Usage() : Usage du script
#===============================================================================
#  arg. 1 : Code de sortie du script
#  arg. 2 : Libelle de sortie ou d'erreur
#===============================================================================
Usage(){
    # Declaration des variables locales
    local _NOM_KSH=$(basename ${0})

    echo -e "Usage: ${_NOM_KSH} -S <IP_Serveur_Consul> -U <BDD_User> -P <BDD_Passwd> -B <BDD_Name> "
    echo -e "                          [-m \"<MARIADB_Service>\"] [-d <Dump_File_Dir>] [-l <Log_File_Dir>] [-v] [-h] \n"

    echo -e " -S <IP_Serveur_Consul>   : Adresse IP serveur consul "
    echo -e " -U <BDD_User>            : User (login de connexion) de la BDD "
    echo -e " -P <BDD_Passwd>          : Password de connexion de la BDD "
    echo -e " -B <BDD_Name>            : Nom de la BDD \n"

    echo -e " [-m \"<MARIADB_Service>\"] : Nom du service MariaDB (par defaut=\"platines-mariadb-server\") "
    echo -e " [-d <Dump_File_Dir>]     : Directory du fichier de dump de BDD cree "
    echo -e " [-l <Log_File_Dir>]      : Directory du fichier de logs cree  "
    echo -e " [-v]                     : Affichage de la version du script "
    echo -e " [-h]                     : Affichage de l'usage du script \n"

    echo -e " Ex.1: ${_NOM_KSH} -v "
    echo -e " Ex.2: ${_NOM_KSH} -u "
    echo -e " Ex.3: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror\n"

    echo -e " Ex.4: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror -m \"my_mariadb_server\" "
    echo -e " Ex.5: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror -d /tmp "
    echo -e " Ex.6: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror -l /tmp "
    echo -e " Ex.7: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror -d /tmp -l /tmp "
    echo -e " Ex.8: ${_NOM_KSH} -S 10.3.9.110 -U user1_ror -P password -B db_ror -m \"my_mariadb_server\" -d /tmp -l /tmp \n"

    echo -e " Par defaut, les fichiers de dump de BDD et de logs sont crees dans le directory courant.\n"

    # Sortie du script avec le code et le libelle associes
    Sortie $1 "$2"
}


#===============================================================================
#> Declaration et initialisation des variables globales
#===============================================================================

# Variables globales
SCRIPT_VERSION="1.0.1.0"
SCRIPT_NAME=$(basename $0)
SCRIPT_BASENAME=$(basename $0 .sh)
#
CONSUL_VM_PORT="8500"
#
BASENAME_FILE="mysqldump_platines"
TODAY="_$(date "+%Y%m%d_%H%M%S")"          # Ex: _20171011_115900
DUMP_FILE="${BASENAME_FILE}${TODAY}.sql"   # Ex: mysqldump_platines_20171011_115900.sql
ZIP_FILE="${DUMP_FILE}.zip"                # Ex: mysqldump_platines_20171011_115900.sql.zip
LOG_FILE="${SCRIPT_BASENAME}${TODAY}.log"  # Ex: platines_dumpdb_20171011_115900.log
TMP_FILE="${SCRIPT_BASENAME}${TODAY}.tmp"  # Ex: platines_dumpdb_20171011_115900.tmp
#
HOME_DIR="$(pwd)"

# Arguments facultatifs a saisir
MARIADB_SERVICE="platines-mariadb-server"
DUMP_DIR="${HOME_DIR}"
LOG_DIR="${HOME_DIR}"

# Arguments obligatoires a saisir
CONSUL_VM_IP=""
PLATINES_USER=""
PLATINES_PASSWD=""
PLATINES_DB=""


#===============================================================================
#> Controle des arguments et initialisation des variables associees
#===============================================================================

# Controle si aucun argument saisi, alors on sort en erreur 1
[ $# -le 0 ] && Usage 1 

# Controle des arguements saisis
while getopts S:U:P:B:m:d:l:vh OPT 
do
    case ${OPT} in
        S)  # Adresse IP serveur consul : <IP_Serveur_Consul>
            CONSUL_VM_IP="${OPTARG}"
            ;;
        U)  # User (login de connexion) de la BDD : <BDD_User>
            PLATINES_USER="${OPTARG}"
            ;;
        P)  # Password de connexion de la BDD : <BDD_Passwd>
            PLATINES_PASSWD="${OPTARG}"
            ;;
        B)  # Nom de la BDD : <BDD_Name>
            PLATINES_DB="${OPTARG}"
            ;;
        m)  # Nom du service MariaDB : <MARIADB_Service>
            MARIADB_SERVICE="${OPTARG}"
            ;;
        d)  # Directory du fichier de dump de BDD cree : [<Dump_File_Dir>]
            DUMP_DIR="${OPTARG}"
            [ ! -d "${DUMP_DIR}" ] && Sortie 1 "Directory des dumps de BDD \"${DUMP_DIR}\" non existant ! "
            ;;
        l)  # Directory du fichier de logs cree : [<Log_File_Dir>]
            LOG_DIR="${OPTARG}"
            [ ! -d "${LOG_DIR}" ] && Sortie 1 "Directory des logs \"${LOG_DIR}\" non existant ! "
            ;;
        v)  # Affichage du numero de version du script
            Sortie 0 "${SCRIPT_NAME} version : ${SCRIPT_VERSION} "
            ;;
        h)  # Affichage de l'usage du script
            Usage 0
            ;;
        *)  # Pour tout autre argument non autorise
            Usage 1
            ;;
    esac
done
shift $((${OPTIND} -1))

# Controle s'il reste encore des arguments non traites, alors on sort en erreur 1
[ $# -gt 0 ] && Usage 1 

# Controle de l'argument obligatoire : -S <IP_Serveur_Consul>
[ -z "${CONSUL_VM_IP}" ] && Sortie 1 "Argument obligatoire (-S) <IP_Serveur_Consul> requis ! "

# Controle de l'argument obligatoire : -U <BDD_User>
[ -z "${PLATINES_USER}" ] && Sortie 1 "Argument obligatoire (-U) <BDD_User> requis ! "

# Controle de l'argument obligatoire : -P <BDD_Passwd>
[ -z "${PLATINES_PASSWD}" ] && Sortie 1 "Argument obligatoire (-P) <BDD_Passwd> requis ! "

# Controle de l'argument obligatoire : -B <BDD_Name>
[ -z "${PLATINES_DB}" ] && Sortie 1 "Argument obligatoire (-B) <BDD_Name> requis ! "


#===============================================================================
#> Validation des arguments et mise a jour des variables associees
#===============================================================================

# Validation de l'argument saisi : -S <IP_Serveur_Consul>
RET=$(echo ${CONSUL_VM_IP} | awk -F. '{print NF}')
[ ${RET} -ne 4 ] && Sortie 1 "Format <IP_Serveur_Consul> incorrect (nnn.nnn.nnn.nnn attendu, ex: 10.3.9.110) !"
! [[ ${CONSUL_VM_IP} == *([0-9]).+([0-9]).+([0-9]).+([0-9]) ]] && Sortie 1 "Format <IP_Serveur_Consul> incorrect (nnn.nnn.nnn.nnn attendu, ex: 10.3.9.110) !"

# Mise a jour des variables associees
LOG_FILE="${LOG_DIR}/${LOG_FILE}"
TMP_FILE="${LOG_DIR}/${TMP_FILE}"


#===============================================================================
#> Code principal
#===============================================================================

# Selection de l'executable : jq
JQ_EXE="jq"
which ${JQ_EXE} > /dev/null 2>&1
if [ $? -ne 0 ]
then
    JQ_EXE=$(find / -name jq-linux64 -print | head -1 2>/dev/null)
    [ $? -ne 0 ] && Sortie 1 "jq-linux64 introuvable !"
fi
#echo -e "JQ_EXE=${JQ_EXE} "

# Initialisation du fichier de logs
cat /dev/null > ${LOG_FILE}
RET_CODE=$?
[ ${RET_CODE} -ne 0 ] && Sortie 2 "[ERROR] - Creation du fichier de logs \"${LOG_FILE}\" impossible !"
Trace_log "(${SCRIPT_NAME}) v${SCRIPT_VERSION} : Debut du traitement "

# Recherche des Adresse IP et Port du serveur MARIADB
Trace_log "Service MARIADB a requeter via curl : \"${MARIADB_SERVICE}\" "
RESULT=$(curl -s http://${CONSUL_VM_IP}:${CONSUL_VM_PORT}/v1/health/service/${MARIADB_SERVICE})
RET_CODE=$?
[ ${RET_CODE} -ne 0 ] && Sortie 3 "[ERROR] - En execution de la commande : curl -s http://${CONSUL_VM_IP}:${CONSUL_VM_PORT}/v1/health/service/${MARIADB_SERVICE} !"
Trace_log "Recherche des Adresse IP et Port du serveur MARIADB : OK "
#echo -e ${RESULT} >> ${LOG_FILE}

# Recuperation de l'Adresse IP du serveur MARIADB
MARIADB_IP=$(echo ${RESULT} | ${JQ_EXE} '.[].Service.Address' | sed 's/"//g')  
! [[ ${MARIADB_IP} == *([0-9]).+([0-9]).+([0-9]).+([0-9]) ]] && Sortie 3 "Format adresse IP serveur MARIADB \"${MARIADB_IP}\" incorrect ! "
Trace_log "Recuperation de l'Adresse IP du serveur MARIADB \"${MARIADB_IP}\" : OK "

# Recuperation du Port du serveur MARIADB
MARIADB_PORT=$(echo ${RESULT} | ${JQ_EXE} '.[].Service.Port')
Trace_log "Recuperation du Port du serveur MARIADB \"${MARIADB_PORT}\" : OK "

# Generation du dump de la base MARIADB
mysqldump -h ${MARIADB_IP} -P ${MARIADB_PORT} -u ${PLATINES_USER} -p${PLATINES_PASSWD} ${PLATINES_DB} > "${DUMP_DIR}/${DUMP_FILE}" 2>${TMP_FILE}
RET_CODE=$?
if [ ${RET_CODE} -ne 0 ]
then
    Trace_log "[ERROR] - En execution de la commande : mysqldump -h ${MARIADB_IP} -P ${MARIADB_PORT} -u ${PLATINES_USER} -p${PLATINES_PASSWD} ${PLATINES_DB} > \"${DUMP_DIR}/${DUMP_FILE}\" !"
    cat ${TMP_FILE} >> ${LOG_FILE}
    Sortie 3
fi
Trace_log "Generation du dump de la base MARIADB \"${DUMP_DIR}/${DUMP_FILE}\" : OK "
cat ${TMP_FILE} >> ${LOG_FILE}

# Zippage du dump de la base MARIADB
cd "${DUMP_DIR}"
zip "${ZIP_FILE}" "${DUMP_FILE}" > ${TMP_FILE} 2>&1
RET_CODE=$?
cd "${HOME_DIR}"
if [ ${RET_CODE} -ne 0 ]
then
    Trace_log "[ERROR] - En execution de la commande : zip \"${ZIP_FILE}\" \"${DUMP_FILE}\" ! "
    cat ${TMP_FILE} >> ${LOG_FILE}
    Sortie 3
fi
Trace_log "Zippage du dump de la base MARIADB \"${DUMP_DIR}/${ZIP_FILE}\" : OK "
cat ${TMP_FILE} >> ${LOG_FILE}

# Suppression du fichier dump de la base MARIADB
rm -f "${DUMP_DIR}/${DUMP_FILE}"
Trace_log "Suppression du fichier dump de la base MARIADB \"${DUMP_DIR}/${DUMP_FILE}\" : OK "

# Compte rendu du fichier dump cree par le traitement
echo -e "Archive du dump cree : ${DUMP_DIR}/${ZIP_FILE} "

Sortie 0


#===============================================================================

